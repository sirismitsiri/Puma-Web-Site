const express = require("express");
const app = express();
const path = require("path");
const hbs = require('hbs');

const register = require("./models/registers");


require("./db/conn");

const port  = process.env.port || 2500
app.use(express.json())
app.use(express.urlencoded({extended:false}));

const pathofdata = path.join(__dirname,"../public")
const viewspath = path.join(__dirname,"../templates/views")
const registerPartials = path.join(__dirname,"../templates/partials")

app.use(express.static(pathofdata))
app.set("view engine","hbs");
app.set("views",viewspath);
hbs.registerPartials(registerPartials)


app.get("/",(req,res)=>{

    imageList = []
    // imageList.push({src:"icones/pumaimg.png",name:"logo"})
    imageList.push({src:"icones/puma-main.jpg",name:"img"})
    imageList.push({src:"icones/pexels-hipkicks.jpg",class:"pexels"})

    res.render("index",{imageList:imageList})
})

app.get("/registration",(req,res)=>{

    imageList = []
    imageList.push({src:"icones/logoimg.png",name:"logo"})
    // imageList.push({src:"icones/background.jpg",name:"logo"})

    res.render("registration",{imageList:imageList})
})

app.post("/registration",async(req,res)=>{
    try {
       const password = req.body.password;
       const cpassword = req.body.confirmpassword;

       if (password === cpassword) {
           const userInfo = new register({
              firstname:req.body.firstname,
              lastname:req.body.lastname,
              email:req.body.email,
              phone:req.body.phone,
              gender:req.body.gender,
              age:req.body.age,
              password:password,
              confirmpassword:cpassword
           });
           const UserReg = await userInfo.save();
           res.status(201).render("index");
       }else{
        res.status(404).render("The password is not matched");
       }

    } catch (error) {
        res.send(error)
    }
})

app.get("/mans",(req,res)=>{
    imageList = []
    imageList.push({src:"icones/shoes.png",name:"logo"})
    imageList.push({src:"icones/seconds.jpg",name:"logo"})
    imageList.push({src:"icones/manwear.jpg",name:"logo"})
    imageList.push({src:"icones/pumabag.jpg",name:"logo"})
    imageList.push({src:"icones/25bag.png",name:"logo"})
    imageList.push({src:"icones/smallbag.png",name:"logo"})
    imageList.push({src:"icones/newman.png",name:"logo"})
    imageList.push({src:"icones/Hoodie.png",name:"logo"})

    res.render("mans",{imageList:imageList})
})


app.get("/womens",(req,res)=>{
    imageList = []
    imageList.push({src:"icones/51E.jpg",name:"logo"})
    imageList.push({src:"icones/2402.avif",name:"logo"})
    imageList.push({src:"icones/2590.jpg",name:"logo"})
    imageList.push({src:"icones/2340.webp",name:"logo"})
    imageList.push({src:"icones/eng.jpg",name:"logo"})
    imageList.push({src:"icones/smallbag.png",name:"logo"})
    imageList.push({src:"icones/a8.jpg",name:"logo"})
    imageList.push({src:"icones/538.jpg",name:"logo"})

    res.render("womens",{imageList:imageList})
})

app.get("/kids",(req,res)=>{
    imageList = []
    imageList.push({src:"icones/61G.webp",name:"logo"})
    imageList.push({src:"icones/370.webp",name:"logo"})
    imageList.push({src:"icones/PUMA-x.avif",name:"logo"})
    imageList.push({src:"icones/55ab.jpg",name:"logo"})
    imageList.push({src:"icones/puma_38.jpg",name:"logo"})
    imageList.push({src:"icones/61P.jpg",name:"logo"})
    imageList.push({src:"icones/71r.jpg",name:"logo"})
    imageList.push({src:"icones/PUMA-x-THE.avif",name:"logo"})

    res.render("kids",{imageList:imageList})
})

app.get("/sports",(req,res)=>{
    imageList = []
    imageList.push({src:"icones/3ff.webp",name:"logo"})
    imageList.push({src:"icones/best-puma.webp",name:"logo"})
    imageList.push({src:"icones/81iw.jpg",name:"logo"})
    imageList.push({src:"icones/61aa.jpg",name:"logo"})
    imageList.push({src:"icones/61j.jpg",name:"logo"})
    imageList.push({src:"icones/61P.jpg",name:"logo"})
    imageList.push({src:"icones/T-shirt.avif",name:"logo"})
    imageList.push({src:"icones/MP00.avif",name:"logo"})

    res.render("sports",{imageList:imageList})
})


app.get("/lifestyle",(req,res)=>{
    res.render("lifestyle")
})

app.get("/outlet",(req,res)=>{
    res.render("outlet")
})

app.get("/login",(req,res)=>{
    res.render("login")
})

app.get("/login",(req,res)=>{
    res.render("login")
})


app.listen(port,(req,res)=>{
    console.log("The Port number 2500 is activated");
})

