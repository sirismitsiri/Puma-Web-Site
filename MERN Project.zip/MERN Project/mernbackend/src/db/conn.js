const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/Registation",{}).then(()=>{
    console.log("The connection is establish sucessfully");
}).catch(()=>{
    console.log("The connection i fail");
})